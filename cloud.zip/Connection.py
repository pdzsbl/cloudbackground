from impala.dbapi import connect
import time

conn = connect(host='192.168.38.129', port=10000, auth_mechanism='PLAIN',
               user='root', password='Tmy15954031572?', database='shop')
cur = conn.cursor()
print('successfully connected')


def login(id, password):
    global cur
    try:
        sql = 'select password from customer where id="%s"' % id
        cur.execute(sql)
        results = cur.fetchall()
        # doesn't exists
        if len(results) == 0:
            return False

        pw = results[0][0]
        # check the given password
        return password == pw
    except:
        return False


def registry(id, password):
    global cur
    try:
        sql = 'select id from customer where id="%s"' % id
        cur.execute(sql)
        results = cur.fetchall()
        # already exists
        if len(results) != 0:
            return False

        sql = 'insert into table customer values("%s", "%s")' % (id, password)
        cur.execute(sql)
        return True
    except:
        return False


def getinfo():
    global cur
    try:
        cur.execute('select * from item limit 15')
        results = cur.fetchall()
        item_info = list()
        for item in results:
            iteml = list(item)
            iteml.append('/usr/hive/data/' + item[0] + '.jpg')
            item_info.append(iteml)

        return item_info

    except:
        return None


def orderinfo(customerid):
    global cur
    try:
        sql = 'select * from ordersheet where customerid="%s"' % customerid
        cur.execute(sql)
        results = cur.fetchall()
        return results
    [
        [orderid,cusid,itemid,num]
    ]
    except:
        return None


def buy(customerid, itemid, quantity):
    global cur
    try:
        sql = 'select remain from item where id="%s"' % itemid
        cur.execute(sql)
        results = cur.fetchall()

        remain = results[0][0]
        # not enough
        if remain < quantity:
            return False

        # timestamp + itemid
        id = str(int(time.time())) + itemid
        new_remain = remain - quantity
        # create order
        sql = 'insert into table ordersheet values("%s", "%s", "%s", %s)' % (id, customerid, itemid, quantity)
        cur.execute(sql)
        # update remain
        sql = 'update table item set remain=%s where id=%s' % (new_remain, itemid)
        cur.execute(sql)

        return True
    except:
        return False


'''
registry("test_user", "pass")
registry("test_user3", "pass")

login("test_user", "password")
login("test_user", "pass")
login("test", "pass")

getinfo()
orderinfo("test_user")

buy("test_user", "11181", 1)
'''
print(orderinfo("test_user"))
'''
cur.close()
conn.close()
'''